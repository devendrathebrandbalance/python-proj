<!--Footer Alanı-->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 cce">
            <div class="logo wow animated fadeInUp animated" data-wow-delay="0s"> <img src="img/metan-logo.png" alt="Image"> </div>
            <!-- end logo -->
            <div class="footer-menu1">
            <div class="menu-quick-links-container">
                <ul id="menu-quick-links" class="menu">
                <li><a href="./about">About Us</a></li>
<li ><a href="./feature">Features</a></li>
<li><a href="./">Projects</a></li>
<li><a href="./privacy-policy">Privacy Policy</a></li>
<li ><a href="./term-and-condition">Terms and Conditions</a></li>
<li><a href="./contact">Contact</a></li>
</ul></div>            </div>
            <div class="bosluk2dt"></div>
            <!-- end footer-info -->
            <ul class="footer-social cce wow animated fadeInUp animated" data-wow-delay="0.5s">
                            <li><a href="#"><i class="flaticon-facebook-1 iconsociaf"></i></a></li>
             
                        <li><a href="#"><i class="flaticon-instagram-1 iconsociaf"></i></a></li>
             
                            <li><a href="#"><i class="flaticon-twitter-1 iconsociaf"></i></a></li>
             
            </ul>
            </div>
        </div>
        <!-- end row --> 
        </div>
    <!-- Copyright -->
    <div class="container">
        <div class="row">
            <div class="col-12">
                <p class="copyright">© 2023 Metan - All Rights Reserved.</p>
            </div>
        </div>
    </div>
    <div id="top" style="cursor: pointer;">
        <i class="flaticon-chevron icontops"></i>
        <div class="bosluk3"></div>
    </div>
</footer>

<!-- <script src='wp-includes/js/dist/vendor/regenerator-runtime.min3937.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script src='wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0' id='wp-polyfill-js'></script> -->

<!-- <script src='wp-content/plugins/contact-form-7/includes/js/index40df.js?ver=5.6' id='contact-form-7-js'></script> -->
<script src='js/team68b3.js' id='team-js'></script>
<script src='js/jquery.min68b3.js' id='jquery-js'></script>
<script src='js/fancybox.min68b3.js' id='fancybox-js'></script>
<script src='js/swiper.min68b3.js' id='swiper-js'></script>
<script src='js/odometer.min68b3.js' id='odometer-js'></script>
<script src='js/wow.min68b3.js' id='wow-js'></script>
<script src='js/scripts68b3.js' id='scripts-js'></script>
<script src='js/3d.jquery68b3.js' id='3d-js'></script>
<script src='js/magnific68b3.js' id='magnific-js'></script>
<script src='js/mag68b3.js' id='mag-js'></script>
<script src='js/pointer68b3.js' id='pointer-js'></script>
<script src='js/yukari-cik68b3.js' id='yukari-cik-js'></script>
<script src='js/custom68b3.js' id='custom-js'></script>
    <!--Cursor Script-->                    
        <script>
        init_pointer({
            
        })
    </script>
</body>


</html>
