<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>Project Detail</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>Project Detail</p>
        </div>
        <!-- end container --> 
</header>
<!--Project Detail Alanı--> 
<section class="hizmetler-detay-sayfasi-alani">
    <div class="container">
        <div class="row">
        <!--Project Detail Görsel Alanı--> 
        <div class="col-lg-6 wow fadeInLeft" data-wow-delay="0.5s">
                <img src="img/pro-detail.jpg" alt="Project Detail" class="prodetal">
        </div>    
        <!--Hizmetler Detay Yazı Alanı-->   
        <div class="col-lg-6">
            
               
            <div class="services-kutu1 wow fadeInLeft" data-wow-delay="0.5s" style="cursor:pointer;">
                <div class="icon-project-detail"><i class="flaticon-hologram-1"></i></div>
                <h3 class="baslik-2 h-yazi-margin-kucuk">Project Title</h3>
                <p class="services-kutu1--yazi-p">
                Moon Project                </p>
            </div>
               
            <div class="services-kutu1 wow fadeInLeft" data-wow-delay="0.6s" style="cursor:pointer;">
                <div class="icon-project-detail"><i class="flaticon-vr-goggles"></i></div>
                <h3 class="baslik-2 h-yazi-margin-kucuk">Used Technologies</h3>
                <p class="services-kutu1--yazi-p">
                AR, VR, artificial intelligence, neural interfaces, blockchain                </p>
            </div>
               
            <div class="services-kutu1 wow fadeInLeft" data-wow-delay="0.7s" style="cursor:pointer;">
                <div class="icon-project-detail"><i class="flaticon-blockchain-5"></i></div>
                <h3 class="baslik-2 h-yazi-margin-kucuk">Project Detail</h3>
                <p class="services-kutu1--yazi-p">
                In this world, the computer screens we use today to connect to a worldwide web of information have become portals to a 3D virtual realm that's palpable -- like real life, only bigger and better. Digital facsimiles of ourselves, or avatars, move freely from one experience to another, taking our identities and our money with us.                </p>
            </div>
                        <div class="bosluk333"></div>
                </div>
    </div> </div>
</section>


<?php include 'footer.php';?> 


