<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>About Us</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>About Us</p>
        </div>
        <!-- end container --> 
</header>
<!--About Info Alanı-->
<section class="hakkimizda-bolumu-anasayfa">
<div class="container">
    <div class="row">
    <div class="col-xl-4">
        <!-- <img class="dotr" src="img/about-meta-11.gif" alt="">
        <img class="postmask" src="img/post-mask1.png" alt=""> -->
    </div>        
    <!--Galeri Görsel Alanı-->
    <div class="col-xl-8 wow fadeInUp" data-wow-delay="0.3s">
        <h2 class="h2-baslik-anasayfa-ozel wow fadeInRight" data-wow-delay="0.4s"> Best Metaverse Terrain System </h2>
        <div class="bosluk333"></div>
    <p class="paragraf wow fadeInRight" data-wow-delay="0.5s">
    <p style="color: #ffffff;">Transact quickly with our agentless, Nft-based digital land purchasing platform. Buy and manage land instantly directly from your blockchain wallet. Setting up your network is very simple. You can buy land tiles with coins. You need to setup in your wallet.</p>
        <div class="bosluk333"></div>
        <div class="container">
            <div class="row">
            <div class="dephh">
                <div class="container">
                    <div class="row">
                                                                    <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 ff">
                                    <div class="iconhh"><i class="flaticon-hologram-1"></i></div>
                                </div>
                                <div class="col-lg-4 ff">
                                    <h2 class="h2-baslik-anasayfa-wth2e wow fade">Virtual Land</h2>
                                    <h4 class="services-kutu2--wt13 wow fade">Buy virtual land and sail to the new world.</h4>
                                </div>
                                <div class="col-lg-2 ff">
                                    <div class="iconhh"><i class="flaticon-video-game"></i></div>
                                </div>
                                <div class="col-lg-4 ff">
                                    <h2 class="h2-baslik-anasayfa-wth2e wow fade">Easy Management</h2>
                                    <h4 class="services-kutu2--wt13 wow fade">The easiest way to manage your Metaverse world.</h4>
                                </div>
                            </div>
                        </div>
                                                <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 ff">
                                    <div class="iconhh"><i class="flaticon-blockchain-5"></i></div>
                                </div>
                                <div class="col-lg-4 ff">
                                    <h2 class="h2-baslik-anasayfa-wth2e wow fade">Metaverse Overview</h2>
                                    <h4 class="services-kutu2--wt13 wow fade">The easiest way to manage your digital plots.</h4>
                                </div>
                                <div class="col-lg-2 ff">
                                    <div class="iconhh"><i class="flaticon-monitoring"></i></div>
                                </div>
                                <div class="col-lg-4 ff">
                                    <h2 class="h2-baslik-anasayfa-wth2e wow fade">Metaverse Analysis</h2>
                                    <h4 class="services-kutu2--wt13 wow fade">Manage your assets with easy accessibility.</h4>
                                </div>
                            </div>
                        </div>
                           
                         
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="bosluk333"></div>
        <a href="../contact/index.html" class="custom-button wow fadeInLeft" data-wow-delay="0.8s">Contact Us →</a>
    </div>
</div></div>
</section>

<!--Info Alanı 2-->
<section class="hakkimizda-bolumu-anasayfa2">
<div class="container">
    <div class="row">        
    <div class="col-xl-8 dds wow fadeInUp" data-wow-delay="0.3s">
        <h2 class="h2-baslik-anasayfa-ozel wow fadeInLeft" data-wow-delay="0.4s"> Metaverse Stats At A Glance </h2>
        <div class="bosluk333"></div>
    <p class="paragraf wow fadeInLeft" data-wow-delay="0.5s">
    <p>Get everything you need for metaverse living: XR apps, devices, tools, services, and more. The open, secure metaverse for individuals, enterprises, and developers. Explore today</p>
        <div class="bosluk333"></div>
        <div class="container">
            <div class="row">
            <div class="dephh">
                <div class="container">
                    <div class="row">
                                                                    <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 fs">
                                    <div class="iconhh"><i class="flaticon-blockchain-2"></i></div>
                                </div>
                                <div class="col-lg-10 fs">
                                    <h2 class="h2-baslik-anasayfa-wth2e1 wow fade">Land NFT Minted</h2>
                                    <h4 class="services-kutu2--wt131 wow fade">1288,962</h4>
                                </div>
                            </div>
                        </div>
                                                <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 fs">
                                    <div class="iconhh"><i class="flaticon-blockchain-4"></i></div>
                                </div>
                                <div class="col-lg-10 fs">
                                    <h2 class="h2-baslik-anasayfa-wth2e1 wow fade">Commission Pool</h2>
                                    <h4 class="services-kutu2--wt131 wow fade">539,820 USD</h4>
                                </div>
                            </div>
                        </div>
                                                <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 fs">
                                    <div class="iconhh"><i class="flaticon-blockchain-5"></i></div>
                                </div>
                                <div class="col-lg-10 fs">
                                    <h2 class="h2-baslik-anasayfa-wth2e1 wow fade">Charity Pool</h2>
                                    <h4 class="services-kutu2--wt131 wow fade">4,2563,539 USD</h4>
                                </div>
                            </div>
                        </div>
                                                <div class="col-lg-12 lefthealtfooter">
                            <div class="row yk" onclick="location.href='#';" style="cursor:pointer;">
                                <div class="col-lg-2 fs">
                                    <div class="iconhh"><i class="flaticon-dashboard"></i></div>
                                </div>
                                <div class="col-lg-10 fs">
                                    <h2 class="h2-baslik-anasayfa-wth2e1 wow fade">Total Land Sold</h2>
                                    <h4 class="services-kutu2--wt131 wow fade">6895,8569,274 USD</h4>
                                </div>
                            </div>
                        </div>
                           
                         
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="bosluk333"></div>
        <a href="#" class="custom-button wow fadeInLeft" data-wow-delay="0.8s">Buy Land Immediately →</a>
    </div>
    <div class="col-xl-4">
        <img class="dotr" src="img/about-meta-33.gif" alt="">
        <img class="dotr1" src="img/dot-11.gif" alt="">
        <img class="postmask" src="img/post-mask1.png" alt="">
    </div>  
</div></div>
</section>

<!--Qua Section-->
<section class="qua1-top">
    <div class="container">
        <div class="row">
            <div class="col-xl-6">
                <div class="bosluk2dt"></div>
                <h2 class="h2-baslik-hizmetler-223 wow fadeInLeft" data-wow-delay="0.5s" style="visibility: visible;"> 
                Learn More About Metaverse                </h2>
                <div class="bosluk2dt"></div>
                <p class=" wow fadeInLeft" data-wow-delay="0.6s">
                Imagine a virtual world where billions of people live, work, shop, learn and interact with each other from the comfort of their seats in the physical world.<br><br>

Get everything you need for metaverse living: XR apps, devices, tools, services, and more. The open, secure metaverse for individuals, enterprises, and developers. Explore today! <br><br>

Preparing your brand for the new realities of marketing. Enter the world of the metaverse to accelerate brand value through digital innovation. For more information, fill out the form on the side.                </p>
            </div>
            <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.5s">
            <div role="form" class="wpcf7" id="wpcf7-f1287-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="1287" />
<input type="hidden" name="_wpcf7_version" value="5.6" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f1287-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="form">
<div class="container">
<div class="row">
<div class="col-xl">
<div class="form__grup wow fadeInLeft" data-wow-delay="0.5s">
                <span class="wpcf7-form-control-wrap" data-name="text-667"><input type="text" name="text-667" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-popup__input" aria-required="true" aria-invalid="false" placeholder="Full Name" /></span>
                </div>
</div>
<div class="col-xl">
<div class="form__grup wow fadeInLeft" data-wow-delay="0.6s">
                <span class="wpcf7-form-control-wrap" data-name="email-217"><input type="email" name="email-217" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-popup__input" aria-required="true" aria-invalid="false" placeholder="Email Address" /></span>
                </div>
</div>
<div class="col-xl">
<div class="form__grup wow fadeInRight" data-wow-delay="0.7s">
                <span class="wpcf7-form-control-wrap" data-name="text-661"><input type="text" name="text-661" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-popup__input" aria-required="true" aria-invalid="false" placeholder="Phone Number" /></span>
                </div>
</div>
<div class="col-xl-12">
<div class="form__grup wow fadeInRight" data-wow-delay="0.8s">
                <span class="wpcf7-form-control-wrap" data-name="textarea-29"><textarea name="textarea-29" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea form-popup__input" aria-invalid="false" placeholder="Your Message"></textarea></span>
                </div>
</div>
<div class="col-xl-12 wow fadeInUp" data-wow-delay="0.9s">
<div class="form__grup">
                <input type="submit" value="Submit Form →" class="wpcf7-form-control has-spinner wpcf7-submit custom-button-form" />
                </div>
</div>
</div>
</div>
</div>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div>
            </div>             
        </div>
    </div>
</section>

<!--Yorumlar-->
<section class="yorumlar-alani-sayfa">
    <div class="container">
        <div class="row">
        <div class="col-12 wow animated fadeIn animated" data-wow-delay="0.5s">
            <div class="h-yazi-ortalama h-yazi-margin-orta-3">
                <div class="icon wow fadeInUp" data-wow-delay="0.5s"><i class="flaticon-review"></i></div>
                <h2 class="h2-baslik-hizmetler-yorum wow fadeInUp" data-wow-delay="0.5s"> What Are Our Customers Saying ? </h2> 
            </div>
                <p class="h2-baslik-hizmetler-yorum__yorum wow fadeInUp" data-wow-delay="0.5s">
                Opinions from our happy customers.                </p>
                <div class="bosluk3a"></div>
            </div>
            <div class="col-12">
                <div class="carousel-classes">
                <div class="swiper-wrapper">
                                                <div class="swiper-slide wow animated fadeInLeft animated" data-wow-delay="0.5s">
                    <div class="class-box">
                    <div class="testimonial-card">
                        <div class="testimon-text">
                        I was very curious about the metaverse. I've come a long way with this site. Thank you.                            <i class="fas fa-quote-right quote"></i>
                        </div>
                        <div class="testimonialimg">
                            <div class="testimonimg"><img src="img/testimonial1-1.png" alt="">
                            <span class="border-layer"></span>
                            </div>
                            <h3 class='person'>Emily</h3>
                        </div>
                        </div>
                        </div>
                <!-- end swiper-slide -->
                </div>
                                <div class="swiper-slide wow animated fadeInLeft animated" data-wow-delay="0.5s">
                    <div class="class-box">
                    <div class="testimonial-card">
                        <div class="testimon-text">
                        However, I made the right investment with the useful information here.                            <i class="fas fa-quote-right quote"></i>
                        </div>
                        <div class="testimonialimg">
                            <div class="testimonimg"><img src="img/man2.png" alt="">
                            <span class="border-layer"></span>
                            </div>
                            <h3 class='person'>Robert</h3>
                        </div>
                        </div>
                        </div>
                <!-- end swiper-slide -->
                </div>
                                <div class="swiper-slide wow animated fadeInLeft animated" data-wow-delay="0.5s">
                    <div class="class-box">
                    <div class="testimonial-card">
                        <div class="testimon-text">
                        Entering the world of the Metaverse was truly a dream come true. And they did it.                            <i class="fas fa-quote-right quote"></i>
                        </div>
                        <div class="testimonialimg">
                            <div class="testimonimg"><img src="img/testimonial3-1.png" alt="">
                            <span class="border-layer"></span>
                            </div>
                            <h3 class='person'>Olivia</h3>
                        </div>
                        </div>
                        </div>
                <!-- end swiper-slide -->
                </div>
                                <div class="swiper-slide wow animated fadeInLeft animated" data-wow-delay="0.5s">
                    <div class="class-box">
                    <div class="testimonial-card">
                        <div class="testimon-text">
                        A professional website that provides useful information about the Metaverse.                            <i class="fas fa-quote-right quote"></i>
                        </div>
                        <div class="testimonialimg">
                            <div class="testimonimg"><img src="img/man1.png" alt="">
                            <span class="border-layer"></span>
                            </div>
                            <h3 class='person'>Adam</h3>
                        </div>
                        </div>
                        </div>
                <!-- end swiper-slide -->
                </div>
                   
                 
                </div>
                </div>      
            </div>
        </div>
    </div>
</section>

<!--Markalar Alanı-->
<section class="markalar">
<div class="container">
        <div class="row">
            <div class="col-lg-12 wow fadeInLeft" data-wow-delay="0.4s">
                <h2 class="h2-baslik-hizmetler-2"> Our Partners & Investors </h2>
                <p class="services-kutu2--yazi1 wow fade animated" style="visibility: visible;">
                Our partners who support us in all our processes                </p>
            </div>
        </div>
    </div>
    <div class="bosluk333"></div>
    <div class="container">
        <div class="row">     
    
            <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-1.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-2.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-4.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-3.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-5.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-6.png" alt="Marka 1" class="marka">
    </div>
    </div>
       
     
    </div>
    </div>
</section>


<?php include 'footer.php';?> 


