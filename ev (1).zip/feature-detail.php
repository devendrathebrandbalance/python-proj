<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>Feature Detail</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>Feature Detail</p>
        </div>
        <!-- end container --> 
</header>
<main>
    <!--Feature Detail-->
    <section class="hizmetlerr-bolumu">
    <div class="h-yazi-ozel h-yazi-margin-ozel">           
    </div>
    <div class="container">
    <div class="row">
        <div class="col">
                <div class="sidebar-service wow fadeInLeft" data-wow-delay="0.5s">          
                                                        <span class="menu-service menuactive" onclick="location.href='#';"><a href="#"><i class="flaticon-right-chevron"></i>Mervarse NFT 1</a></span>
                                
                                        <span class="menu-service " onclick="location.href='#';"><a href="#"><i class="flaticon-right-chevron"></i>Mervarse NFT 2</a></span>
                                
                                        <span class="menu-service " onclick="location.href='#';"><a href="#"><i class="flaticon-right-chevron"></i>Mervarse NFT 3</a></span>
                                
                                        <span class="menu-service " onclick="location.href='#';"><a href="#"><i class="flaticon-right-chevron"></i>Mervarse NFT 4</a></span>
                                
                                        <span class="menu-service " onclick="location.href='#';"><a href="#"><i class="flaticon-right-chevron"></i>Mervarse NFT 5</a></span>
                                
                      
                    </div> 
                     
            <div class="bosluk3"></div>
             <div role="form" class="wpcf7" id="wpcf7-f809-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="809" />
<input type="hidden" name="_wpcf7_version" value="5.6" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f809-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="callbackform wow fadeInUp" data-wow-delay="0.7s">
<div class="bosluk333"></div>
<h2 class="h2-baslik-hizmetler-2">
        Information Form<br />
    </h2>
<p class="paragraf-popup">
        Learn more.
    </p>
<div class="form-popup">
<div class="form-popup__grup">
            <span class="wpcf7-form-control-wrap" data-name="text-667"><input type="text" name="text-667" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-popup__input" aria-required="true" aria-invalid="false" placeholder="Full Name" /></span><br />
            <label for="text-667" class="form-popup__label"></label>
        </div>
<div class="form-popup__grup">
            <span class="wpcf7-form-control-wrap" data-name="email-217"><input type="email" name="email-217" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-popup__input" aria-required="true" aria-invalid="false" placeholder="Email Address" /></span><br />
            <label for="email-217" class="form-popup__label"></label>
        </div>
<div class="form-popup__grup">
            <span class="wpcf7-form-control-wrap" data-name="text-661"><input type="text" name="text-661" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-popup__input" aria-required="true" aria-invalid="false" placeholder="Phone Number" /></span><br />
            <label for="text-661" class="form-popup__label"></label>
        </div>
<div class="form-popup__grup">
            <span class="wpcf7-form-control-wrap" data-name="textarea-29"><textarea name="textarea-29" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea form-popup__input" aria-invalid="false" placeholder="Your Message"></textarea></span><br />
            <label for="text-661" class="form-popup__label"></label>
        </div>
<div class="form-popup__grup">
<div class="or">
              <input type="submit" value="Submit Form →" class="wpcf7-form-control has-spinner wpcf7-submit custom-buttonf" />
            </div>
</div>
<p><br>
   </div>
</div>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div>
             </div>

            
            <div class="col-lg-8">
            <div class="bosluk44"></div>
            <div class="galeri wow fadeInRight" data-wow-delay="0.7s">
                <img src="img/feature-detail.png" alt="IT Support Services" class="galeri__gorsel galeri__gorsel--3">
            </div>
            <div class="bosluk3"></div>
            <h2 class="h2-baslik-anasayfa-ozel wow fade">Feature Detail</h2>
            <div class="bosluk333"></div>
            <p class="paragraf wow fade">
            <p>Imagine a virtual world where billions of people live, work, shop, learn and interact with each other from the comfort of their seats in the physical world.</p>
<p>&nbsp;</p>
<p>In this world, the computer screens we use today to connect to a worldwide web of information have become portals to a 3D virtual realm that&#8217;s palpable like real life, only bigger and better. Digital facsimiles of ourselves, or avatars, move freely from one experience to another, taking our identities and our money with us.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Get everything you need for metaverse living: XR apps, devices, tools, services, and more. The open, secure metaverse for individuals, enterprises, and developers. Explore today!</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>Preparing your brand for the new realities of marketing. Enter the world of the metaverse to accelerate brand value through digital innovation. For more information, fill out the form on the side.</p>
            </p>
            <div class="bosluk333"></div>
          </div>
    </div>
</div>
    </section>
</main>

<?php include 'footer.php';?> 


