<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>Projects</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>Projects</p>
        </div>
        <!-- end container --> 
</header>
<!--Projects-->
<section class="serviceb-alani">
<div class="galeriservice">
<img class="imagerotateservice" src="img/nft-rotate1.png" alt="" >
</div>
    <div class="h-yazi-ortalama h-yazi-margin-orta-3">
        <h2 class="h2-baslik-hizmetler-2 wow fade">Check Out The Most Creative NFT Projects</h2>
        <p class="services-kutu2--yazi1 wow fade animated" style="visibility: visible;">
        Metaverse is a marketplace dedicated to the digital world.        </p>
    </div>
    <div class="container">
    <div class="row">
        <div class="col-12">
            <div class="carousel-classes">
            <div class="swiper-wrapper">
                                    <div class="swiper-slide">
            <div class="box-style2 box-primary-color2 wow fadeInLeft" data-wow-delay="0.5s">
                <img class="efozel2" src="img/nft-1.jpg" alt="">
                <div class="descontent">
                    <div class="or">
                        <div class="bosluk4e"></div>
                        <h2>Moon NFT</h2>
                        <div class="bosluk333"></div>
                        <div class="class-button">
                            <a class="custom-button" href="#">Project Review →</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end swiper-slide -->
            </div>
                        <div class="swiper-slide">
            <div class="box-style2 box-primary-color2 wow fadeInLeft" data-wow-delay="0.6s">
                <img class="efozel2" src="img/nft-2.jpg" alt="">
                <div class="descontent">
                    <div class="or">
                        <div class="bosluk4e"></div>
                        <h2>Kawain NFT</h2>
                        <div class="bosluk333"></div>
                        <div class="class-button">
                            <a class="custom-button" href="#">Project Review →</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end swiper-slide -->
            </div>
                        <div class="swiper-slide">
            <div class="box-style2 box-primary-color2 wow fadeInRight" data-wow-delay="0.7s">
                <img class="efozel2" src="img/nft-3.jpg" alt="">
                <div class="descontent">
                    <div class="or">
                        <div class="bosluk4e"></div>
                        <h2>Sura NFT</h2>
                        <div class="bosluk333"></div>
                        <div class="class-button">
                            <a class="custom-button" href="#">Project Review →</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end swiper-slide -->
            </div>
                        <div class="swiper-slide">
            <div class="box-style2 box-primary-color2 wow fadeInRight" data-wow-delay="0.8s">
                <img class="efozel2" src="img/nft-4.jpg" alt="">
                <div class="descontent">
                    <div class="or">
                        <div class="bosluk4e"></div>
                        <h2>Nix NFT</h2>
                        <div class="bosluk333"></div>
                        <div class="class-button">
                            <a class="custom-button" href="#">Project Review →</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end swiper-slide -->
            </div>
               
             
            </div>
            </div>      
        </div>
    </div>
</div>
 </div>
</section>

<!--Markalar Alanı-->
<section class="markalar">
<div class="container">
        <div class="row">
            <div class="col-lg-12 wow fadeInLeft" data-wow-delay="0.4s">
                <h2 class="h2-baslik-hizmetler-2"> Our Partners & Investors </h2>
                <p class="services-kutu2--yazi1 wow fade animated" style="visibility: visible;">
                Our partners who support us in all our processes                </p>
            </div>
        </div>
    </div>
    <div class="bosluk333"></div>
    <div class="container">
        <div class="row">     
    
            <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-1.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-4.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-3.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-2.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-5.png" alt="Marka 1" class="marka">
    </div>
    </div>
        <div class="col-lg-2">
    <div class="h-yazi-ortalama h-yazi-margin-kucuk-21 wow animated fadeInUp animated" data-wow-delay="0.5s">
        <img src="img/metanlogos-6.png" alt="Marka 1" class="marka">
    </div>
    </div>
       
     
    </div>
    </div>
</section>



<?php include 'footer.php';?> 


