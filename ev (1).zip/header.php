<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name='robots' content='max-image-preview:large' />
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!-- <link rel='stylesheet' id='wp-block-library-css' href='wp-includes/css/dist/block-library/style.min6a4d.css?ver=6.1.1' media='all' />
<link rel='stylesheet' id='classic-theme-styles-css' href='wp-includes/css/classic-themes.min68b3.css?ver=1' media='all' /> -->
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='font-css' href='css/icon-font68b3.css' media='all' />
<link rel='stylesheet' id='style-css' href='css/style68b3.css' media='all' />
<link rel='stylesheet' id='fancybox-css' href='css/fancybox.min68b3.css' media='all' />
<link rel='stylesheet' id='swiper-css' href='css/swiper.min68b3.css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='css/bootstrap.min68b3.css' media='all' />
<link rel='stylesheet' id='odometer-css' href='css/odometer.min68b3.css' media='all' />
<link rel='stylesheet' id='flaticon-css' href='css/flaticon68b3.css' media='all' />
<link rel='stylesheet' id='custom-css' href='css/custom68b3.css' media='all' />

<style>
.swiper-pagination-bullet {margin-left:5px;}
.navbar-nav .nav-link:hover {color: #d02ef0;}
.slider .main-slider .swiper-slide .container a {background: none;border: 1px solid #ffffff;color: #ffffff;}
.slider .main-slider .swiper-slide .container a:hover {background: none;border: 1px solid #ffffff;color: #ffffff;}
.navbar .navbar-button a {color: #d02ef0;border: 2px solid #d02ef0;}
.navbar .navbar-button a:hover {color: #d02ef0;}
.slider .button-next:hover {background:#09cfff;color: #ffffff;border-radius: 5px;}
.price-list-price {color: #d02ef0;}
.price-list-separator {border-bottom-color: #d02ef0;}
.custom-button{background:#d02ef0;}
.counter-box h6:after{display:none;}
.hamburger-menu span{background: #d02ef0;}
.cardContent h2 {background: #d02ef0;}
.custom-button:hover { font-family: Outfit;background:none;color:#ffffff; 
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
}
.custom-button12{background:#d02ef0;}
.iconsocia:hover {background: linear-gradient(to right, #09cfff 0%, #d02ef0 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;}
.wpcf7-validates-as-date {border-bottom: 0.3rem solid #09cfff;}
.side-widget .address a { border: 1px solid #d02ef0;border-radius: 5px;}
.side-widget .address a:hover {border: 1px solid #d02ef0;}
.custom-button12:hover{background:#09cfff;}
.custom-button-form {border-bottom: 0.3rem solid #d02ef0;    background: none;
    border: 1px solid #ffffff;color:#ffffff;}
.custom-button-form:hover {border-bottom: 0.3rem solid #d02ef0;    background: none;
border: 1px solid #ffffff;color:#ffffff;}
.menueffect a:hover {color: #09cfff;}
.slider .button-prev {background:#d02ef0;color: #ffffff;border-radius: 5px;}
.slider .button-next {background:#d02ef0;color: #ffffff;border-radius: 5px;}
.slider .button-prev:hover {background:#09cfff;color:#ffffff;border-radius: 5px;}
.content-section {background: #d02ef0; }
.component-systemTabs .cards .card img { border: 1px solid #ffffff;border-radius: 5px;padding-bottom: 74px;padding-top: 10px;}
input#wp-block-search__input-1 {border-bottom: 0.3rem solid #d02ef0;}
.content-section.bottom-dark-spacing:after {background: #d02ef0; }
.section-title h2 {color: #d02ef0;}
.image-box .time {color: #d02ef0; }
.menueffect a:before {background-image: linear-gradient(to right, #d02ef0, #09cfff); }
.side-content form button[type="submit"] {color: #d02ef0; }
.side-image .side-timetable li b { color: #d02ef0; }
.side-member figcaption {background: #d02ef0;}
.custom-progress span {color: #d02ef0; }
.bg-light {z-index:8;}
.menueffect a:after {display:none;}
.dropdown-menu {background:#000;}
.custom-progress .progress-bar .progress {background: #d02ef0;}
.tab-wrapper .tab-nav li.active a {background: #d02ef0;}
.tab-wrapper .tab-nav li.active a:hover {background: #09cfff; }
.tab-wrapper .tab-item .tab-inner {background: #d02ef0; }
.tab-wrapper .tab-item .tab-inner ul li span {color: #d02ef0; }
.service-box {background: #d02ef0; }
.service-box:before {background: #d02ef0;}
.image-overlap-box figure {background: #d02ef0; }
.image-overlap-box .content a:hover {color: #09cfff; }
.video {background: #d02ef0; }
.video a {color: #d02ef0;}
.class-box figure {margin-bottom: 126px;}
.text-box h5 {color: #d02ef0;}
.recent-news figure {background: #d02ef0;}
.recent-news .content h3 a { color: #d02ef0; }
.recent-news .content small span {background: #d02ef0;}
.blog-box figure {background: #d02ef0; }
.blog-box .content h3 a {color: #d02ef0;}
.blog-box .content blockquote {color: #d02ef0;}
.sidebar .widget .widget-title {color: #d02ef0;}
.sidebar .widget .widget-title:before {background: #d02ef0;}
.sidebar .widget form input[type="submit"] {background: #d02ef0;}
.sidebar .widget .categories li a {color: #d02ef0;}
.branch-box h6 {color: #d02ef0;}
.branch-box a {color: #d02ef0;}
.member-box figcaption {background: #d02ef0;}
.icon {background: #d02ef0;}
.iconsv {background: none;}
.iconk {color: #f5f5f5;}
li a:hover {color: #d02ef0;}
.iconk:hover { color: #09cfff; }
.sidebar-service {background: none;}
span.menu-service {background: none;
    border: 1px solid #ffffff;color: #ffffff;}
span.menu-service:hover { background: none;
    border: 1px solid #ffffff;color: #ffffff;}
span.menu-service.menuactive { background: none;
    border: 1px solid #ffffff;color: #ffffff; }
.iconleft {background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;}
.iconleft:hover { background: linear-gradient(to right, #09cfff 0%, #d02ef0 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;}
a.menucolor { color: #d02ef0; }
a.menucolor:hover { color: #09cfff; }
.pagination .page-item .page-link { color: #d02ef0; }
.footer .footer-info a { color: #d02ef0; }
.footer .footer-social li a:hover {background: none;}
.iconk { color: #d02ef0; }
.iconk:hover { color: #09cfff; }
.iconleft {color: #d02ef0;}
.iconk { color: #d02ef0;}
.iconk:hover { color: #09cfff; }
.iconleft {color: #d02ef0;}
span.menu-service {color: #d02ef0;}
textarea#comment {border-bottom: 0.3rem solid #d02ef0;background: none;color: #ffffff;}
input#author {border-bottom: 0.3rem solid #d02ef0;background: none;color: #ffffff;}
input#email {border-bottom: 0.3rem solid #d02ef0;background: none;color: #ffffff;}
input#url {border-bottom: 0.3rem solid #d02ef0;background: none;color: #ffffff;}
h3#reply-title, span.required-field-message, span#email-notes{color: #ffffff;}
.paketler2__on--arkayazi-1 {background: linear-gradient(to right bottom, #d02ef0, #09cfffd7);}
.form__input {
    background: none;
    border: 1px solid #ffffff;color: #ffffff;
    border-radius: 5px;
    padding: 30px;
}
.form__input:focus{border-bottom: 0.3rem solid #d02ef0;}
.form__input:focus:invalid{border-bottom: 0.3rem solid #d02ef0;}
.form__radio-buton {border: 0.5rem solid #d02ef0;}
.form__radio-buton::after {background-color: #d02ef0;border-radius: 5px;}
.form-popup__input {border-bottom: 0.3rem solid #d02ef0;border-radius: 5px;}
.form-popup__input:focus {border-bottom: 0.3rem solid #d02ef0;border-radius: 5px;}
.form-popup__input:focus:invalid {border-bottom: 0.3rem solid #d02ef0;}
.hizmetler-kutu--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.ozellik-kutu--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.post-kutu--icon {background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.yorum-kutu--icon {background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.ozellik-kutu-iletisim--icon {background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.baslik-4--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.yukaricik {background-image: linear-gradient(to right bottom, #d02ef0,#09cfff);}
.footer-404 {background-image: linear-gradient(to right bottom, #d02ef0,#09cfff);}
.form-alani {background-image: linear-gradient(to right bottom,#d02ef0,#09cfff);}
.h2-baslik-hizmetler {background-image: linear-gradient(to right, #d02ef0, #09cfff);}
.h2-baslik-hizmetler__paragraf {color: #d02ef0;}
.h2-baslik-hizmetler-2 {color:#ffffff;}
.side-widget small {color: #fff;}
.swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active {background: #d02ef0;}
.swiper-pagination .swiper-pagination-bullet{background: #d02ef0e6;}
::-webkit-scrollbar-thumb {background: #0f0f0f;}
.custom-buttonw1 { border-bottom: 0.3rem solid #d02ef0;}
.iconsocia {background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;}
.paketler3__gorsel--1 { background-image: linear-gradient(to right bottom, #d02ef0, #09cfff)}
.paketler3__on--arkayazi-1 { background-image: linear-gradient(to right bottom, #d02ef0, #09cfff)}
p.countb {background: #d02ef0;}
.icontops {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    color:#fff;
    border-radius: 10px;
}
.icontops:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
}
img.efc {
    z-index: 2;
    width: 100%;
    position: absolute;
    left: 0;
    top: -105px;
    background-size: cover !important;
    background-position: center !important;
}
.slider .main-slider .swiper-slide {
    background: #000000;
}
p.footerp {color: #ffffff;}
input#submit {background: #d02ef0;}
.custom-buttonw:hover{background: #d02ef0;}
.comment-meta.commentmetadata a:hover {color: #09cfff; }
a.comment-edit-link:hover {color: #09cfff; }
p.logged-in-as a:hover {color: #09cfff; }
.menu-item a:hover {color: #09cfff; }
li a {color: #d02ef0; }
.tag-cloud-link {color: #d02ef0; }
.tagcloud a:hover {color: #09cfff; }
li#recent-posts-5 a:hover {color: #09cfff; }
input#s {border-bottom: 0.3rem solid #09cfff;background:none; color:#ffffff;}
.telh {background: none;
    color: #ffffff;
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    transition: all 0.9s;
}
.telh:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
    transition: all 0.9s;
}
.col-lg-10.fs {
    border: 1px solid rgb(255 255 255 / 12%);
}
.col-lg-2.fs, .col-lg-10.fs {
    margin-bottom: 10px;
}
.side-widget .address {color:#ffffff;}
.hakkimizda-bolumu-anasayfa {background: #000000 url(img/star.png) repeat top center;}
.hakkimizda-bolumu-anasayfa2 {background: #000000 url(img/star.png) repeat top center;}
.info-featured {background: #000000 url(img/star.png) repeat top center;}
.markalar {background: #000000 url(img/star.png) repeat top center;}
.serviceb-alani{background: #000000 url(img/star.png) repeat top center;}
.qua1-top{background: #000000 url(img/star.png) repeat top center;}
.yorumlar-alani-sayfa{background: #000000 url(img/star.png) repeat top center;}
.footer{background: #000000 url(img/star.png) repeat top center;}
.side-widget {background: #000000 url(img/star.png) repeat top center;z-index:9;}
.team-section{background: #000000 url() repeat top center;}
.ozellika{background: #000000 url() repeat top center;}
.hizmetler-detay-sayfasi-alani {background: #000000 url() repeat top center;}
.page-header {background: #000000 url(img/star.png) repeat top center;}
.paketler-alani{background: #000000 url() repeat top center;}
.hizmetlerr-bolumu{background: #000000 url() repeat top center;}
.iletisim-icon-alani{background: #000000 url() repeat top center;}
.iletisim-form-alani{background: #000000 url() repeat top center;}
.news-alani-sayfa{background: #000000 url(img/star.png) repeat top center;}
.tagcloud, .tag-cloud-link, .widget, .post-kutu, .ozellik-kutu-iletisim, .paketler4__on--onyazi, .paketler4__on--arkayazi-1, input#submit{
    background: none;
    border: 1px solid #ffffff;
}
img.postmask {
    position: relative;
    z-index: 5;
    margin-top: -537px;
}
.services-kutu2 {
    background: none;
    border:none;
}
.member-box figcaption {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
}
.member-box figcaption:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
}
.icon-project-detail {
    font-size: 65px;
    color: #fff;
}
h3.baslik-2.h-yazi-margin-kucuk {
    font-size: 24px;
    color: #fff;
}
label{color:#ffffff;}
/* Special Effects */
@keyframes move-twink-back {
    from {background-position:0 0;}
    to {background-position:-10000px 5000px;}
} 
.metaverse, .fadess {
  position:absolute;
  top:0;
  left:0;
  right:0;
  bottom:0;
  width:100%;
  height:100%;
  display:block;
}
 .metaverse {
  background:#00000000 url(img/star.png) repeat top center;
  z-index:2;
}


.metaverse, .fadess, .clouds {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    display: block;
}
.clouds{
    background:transparent url(img/cloudss3.png) repeat top center;
    z-index:5;

  -moz-animation:move-clouds-back 200s linear infinite;
  -ms-animation:move-clouds-back 200s linear infinite;
  -o-animation:move-clouds-back 200s linear infinite;
  -webkit-animation:move-clouds-back 200s linear infinite;
  animation:move-clouds-back 200s linear infinite;
  opacity:0.5;
  background-repeat: round;
  pointer-events: none;
}

@keyframes move-clouds-back {
    from {background-position:0 0;}
    to {background-position:10000px 0;}
}
@-webkit-keyframes move-clouds-back {
    from {background-position:0 0;}
    to {background-position:10000px 0;}
}
@-moz-keyframes move-clouds-back {
    from {background-position:0 0;}
    to {background-position:10000px 0;}
}
@-ms-keyframes move-clouds-back {
    from {background-position: 0;}
    to {background-position:10000px 0;}
}
 
.card{
    background:transparent url(http://2941/) repeat;
    z-index:3;

  -moz-animation:move-clouds-backs 20s linear infinite;
  -ms-animation:move-clouds-backs 20s linear infinite;
  -o-animation:move-clouds-backs 20s linear infinite;
  -webkit-animation:move-clouds-backs 20s linear infinite;
  animation:move-clouds-backs 20s linear infinite;
  opacity:1;
}
@keyframes move-clouds-backs{
    from {background-position:0 0;}
    to {background-position:250px 0;}
}
@-webkit-keyframes move-clouds-backs {
    from {background-position:0 0;}
    to {background-position:250px 0;}
}
@-moz-keyframes move-clouds-backs {
    from {background-position:0 0;}
    to {background-position:250px 0;}
}
@-ms-keyframes move-clouds-backs {
    from {background-position: 0;}
    to {background-position:250px 0;}
}
/* Finish */
.dephh {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
}

.dephh {
    padding: 0px;
    border-radius: 5px;
    padding-bottom: 6px;
}
.col-lg-2.fs {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    border-radius: 5px;
    transition: all 0.9s;
}
.col-lg-2.fs:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
    border-radius: 5px;
    transition: all 0.9s;
}
.col-lg-2.ff {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    border-radius: 5px;
    transition: all 0.9s;
}
.col-lg-2.ff:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
    border-radius: 5px;
    transition: all 0.9s;
}
.col-lg-4.ff{
    border: 1px solid rgb(255 255 255 / 12%);
}
.iconhh {
    padding: 0;
    text-align: center;
    height: auto;
    border-radius: 10rem;
    transition: .5s;
    margin-left: auto;
    margin-right: auto;
    font-size: 60px;
    z-index: 2;
    position: relative;
    background: none;
    line-height: 0;
}
.iconhh {
    color: #ffffff;
}
h2.h2-baslik-anasayfa-wth2e {
    color: #ffffff;
    font-family: Outfit;
    font-size: 20px;
    font-weight: 900;
}
h2.h2-baslik-anasayfa-wth2e1 {
    color: #ffffff;
    font-family: Outfit;
    font-size: 25px;
    font-weight: 900;
}
.or56 {
    text-align: center;
    display: inline-block;
    flex-wrap: wrap;
    text-align: center;
    justify-content: center;
    align-items: center;
}
.iconwr {
    line-height: 20px;
    color: #fff;
    transition: .5s;
    font-size: 65px;
}
.dep:hover h4, .dep:hover h3 {
    color: #fff;
    position: relative;
}
.dep {
position: relative;
background:none;
}
.dep:before {
position: absolute;
-webkit-transition: all 0.8s ease;
transition: all 0.8s ease;
z-index: -1;
border-radius:5px;
}
.dep:before {
bottom: 0;
display: block;
height: 100%;
width: 0%;
content: "";
z-index: -1;
background-image: linear-gradient(to right, #d02ef0, #09cfff);
border-radius:5px;
left: 0;
}
.box-style2.box-primary-color2:hover::after {
    opacity: 1;
    visibility: visible;
}
.box-style2:hover {
    -webkit-animation: electricef2 0.4s both;
    animation: electricef2 0.4s linear;
}
.box-style2 {
    position: relative;
    -webkit-transition: .5s;
    transition: var(--transition);
    width: 100%;
    height: 100%;
    color: #000;
}
.box-style2 i {
    color: #000;
    font-size: 60px;
}
.box-style2:hover .class-button {
    visibility: visible;
    opacity: 1;
    margin-bottom: 0;
}
.box-style2 .class-button {
    visibility: hidden;
    opacity: 0;
    margin-bottom: -80px;
    transition: all .3s ease-in-out;
}
.box-style2 h2 {
    font-size: 22px;
    margin-top: -20px;
    font-weight: 600;
}

.descontent {
    z-index: 1;
}
img.efozel2 {
    border-radius: 5px;
}
.box-style2 .descontent {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 2px 9px 20px;
}
.descontent:before {
  position: absolute;
  content: "";
  height: 100%;
  width: 100%;
  bottom: -5px;
  background-image: linear-gradient(to right, #d02ef0, #09cfff);
  border-radius: 5px;
  transition: all .9s ease-in-out;
  z-index: -1;
  left: 0;
  right: 0;
}
.descontent:after {
    position: absolute;
    content: "";
    height: 100%;
    width: 95%;
    bottom: 10px;
    background-image: linear-gradient(to right, #d02ef06d, #09cfff6d);
    border-radius: 5px;
    transition: all .9s ease-in-out;
    z-index: -2;
    right: 8px;
}
.dep:hover:before{
    opacity: 1;
    width: 100%;
}
.dep:hover h4, .dep:hover h3 {
    color: #fff;
    position: relative;
}
.dep {box-shadow: 0px 0px 5px #b5b5b561;}
h3.prongl {
    font-family: Outfit;
    font-size: 22px;
    color: #fff;
    font-weight: 600;
}
h4.infostextgl {
    font-family: Outfit;
    font-size: 16px;
    font-weight: 400;
    color: #ffffff;
}
.row.ff {
    border-radius: 5px;
    pointer-events: none;
    cursor: default;
    z-index: -1;
}
.col-lg-3.ds {
    position: relative;
    z-index: 2;
    pointer-events: auto;
    cursor: default;
    width: 100%;
    text-align: center;
}
.services-kutu2--wt13 {
    color: #fff;
    font-family: Outfit;
    font-size: 16px;
    font-weight: 400;
}
img.dotr1 {
    margin-top: -310px;
    margin-left: -373px;
    z-index: 0;
    position: relative;
}
.col-xl-8.dds {
    z-index: 2;
}
.services-kutu2--wt131 {
    color: #fff;
    font-family: Outfit;
    font-size: 24px;
    font-weight: 400;
}
.iconsociai {background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent; }
.iconsociai:hover {background: linear-gradient(to right, #09cfff 0%, #d02ef0 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent; }
::selection { background-color: #d02ef0; }
::-webkit-scrollbar-thumb { background-color: #0f0f0f; }
.ozellik-kutu-yorumlar--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.services-kutu1--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.services-kutu2--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
.services-kutu3--icon{background-image: linear-gradient(to right, #d02ef0,#09cfff);}
b.fn a:hover {color: #09cfff; }
li a:hover {color: #09cfff;}
select {border-bottom: 0.3rem solid #d02ef0;}
.wp-block-latest-posts__list a:hover {color: #d02ef0;}
#tabs li  {color: #ffffff;border-bottom: 4px solid #d02ef0;}
.custom-buttonf {background: none; border:1px solid #ffffff;}
.custom-buttonf:hover {background: none; border:1px solid #ffffff;}
.beer-slider {border: 4px solid #d02ef0;}
.button-next1 {color: #d02ef0;border: none;background:none;border-radius: 5px;}
.button-next1:hover{border: none;background:none;}  
.button-prev1{color: #d02ef0;border: none;background:none;border-radius: 5px;}
.button-prev1:hover{border: none;background:none;} 
.footer .footer-social li a {background: none;}
.wp-post-image {height: 100%;}
.services-kutu2--yazi1 {width:100%;}
.or{color: #ffffff;}
.footer .footer-menu li a {color: #ffffff;}
.footer .footer-menu li:before {background: #ffffff;}
.iconserv {color: #d02ef0;margin-top: 27rem;margin-bottom: -10px;}
.iconserv:hover {color: #09cfff;margin-top: 27rem;margin-bottom: -10px;}
h3.horoscope a{
    font-family: Outfit; 
    font-size:20px; color:#ffffff;
}
h3.horoscoped{font-family: Outfit; font-size:16px; color:#000000;text-align:center;}
p.windownd{font-family: Outfit; font-size:16px; color:#000000;text-align:center;}
.component-systemTabs .cards .card:hover img {box-shadow: 0px 0px 25px #ffffff;}
.galeriservice {
    position: relative;
    z-index: 2;
}
.carousel-classes{z-index: 2;}
.sticky{
    position: fixed;
    left: 0;
    width: 100%;
    background:#000000;
    transition: all 0.9s;
}
.posto {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 100%;
    padding: 15px;
}
/* text primary */
.cardContent h2 {font-family: Outfit;}
.component-systemTabs .cards .card .cardContent button {background: #d02ef0;font-family: Outfit;}
.footer-menu1 a:hover {
    background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.footer-menu1 a {
    color: #fff;
    font-size: 17px;
    margin-left: 10px;
    margin-right: 10px;
}
.footer-menu1 {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    width: 100%;
}
.footer-menu1:before, .footer .copyright:before {
    flex: 1;
    content: "";
    height: 1px;
    width: 50%;
    z-index: 1;
    background-color: #fff;
}
.footer-menu1:after, .footer .copyright:after {
    flex: 1;
    content: "";
    height: 1px;
    width: 50%;
    z-index: 1;
    background-color: #fff;
}
ul#menu-quick-links {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    width: 100%;
    text-align: center;
}
.person {
    color: #ffffff;
    font-family: Outfit; 
    font-size: 16px; 
    font-weight: 400; }
.ozellik-kutu-iletisim--yazi {color: #fff; font-family: Outfit; font-size: 20px; font-weight: 400; }
.footer-info p {color: #ffffff;font-family: Outfit; font-size: 16px; font-weight: 400; }
p {font-family: Outfit; font-size: 16px; font-weight: 400; }
.h2-baslik-hizmetler-21__paragraf {font-family: Outfit; font-size: 16px; font-weight: 400; }
.paketler3__icerik ul li {font-family: Outfit; font-size: 16px; font-weight: 400; }
body {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400; }
.paragraf{color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.paragraf-info {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400;  }
ul.post-categories a {color: #ffffff; font-family: Outfit; font-size: 16px; }
span.date {color: #ffffff; font-family: Outfit; font-size: 18px; } 
span.category {color: #ffffff; font-family: Outfit; font-size: 16px;}
span.tt { color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400;  } 
.paragraf-info a {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.paragraf-sol-beyaz a {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400; }
.paragraf-sol-beyaz-orta a {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400; }
.paragraf-ahp a {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.paragraf-pdetay a {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.paragraf-404 a {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.h2-baslik-hizmetler-yorum__yorum {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400;  }
.testimon-text {color: #000000; font-family: Outfit; font-size: 16px; font-weight: 400; }
.post-kutu p {color: #ffffff; text-align:center;font-family: Outfit; font-size: 16px; font-weight: 400; }
.services-kutu2--yazi1 {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400; }
.h2-baslik-hizmetler-2__paragraf {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400; }
.paragraf-popup {color: #ffffff; font-family: Outfit; font-size: 16px; font-weight: 400;  }
ul.post-categories {color: #d02ef0; font-family: Outfit; font-size: 16px;}
.services-kutu2--yazi { font-family: Outfit;  font-size: 16px;}

/* headings */
.countt{background:#ffffff;font-family: Outfit;}
.countb{background:#ffffff;font-family: Outfit;}
.h2-baslik-hizmetler-223__paragraf {color:#ffffff;}
.component-systemTabs .cards .card .cardContent h2 {background:none;color:#ffffff;font-family: Outfit;}
.h2-baslik-anasayfa {background-image: linear-gradient(to right, #ffffff,#09cfff);border-bottom: .1rem solid #d02ef0; font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-anasayfa-ozel {color: #ffffff; font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-hizmetler-223 {color: #ffffff; font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-anasayfa-blog {background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-ahb{background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-bottom {background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-404{background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-footer{background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-iletisim-ozel{background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-popup {background-image: linear-gradient(to right, #ffffff, #09cfff); font-family: Outfit; font-size: 32px; font-weight: 700; }
.baslik-3-h {color: #ffffff; font-family: Outfit; font-size: 32px; font-weight: 700; }
.baslik-33 {color: #ffffff; font-family: Outfit; font-size: 32px; font-weight: 700; }
.baslik-star{color:#ffffff; font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-hizmetler-yorum {color: #ffffff;font-family: Outfit; font-size: 32px; font-weight: 700; }
.baslik-3s {color:#ffffff; font-family: Outfit; }
.baslik-3white {font-family: Outfit; }
.baslik-orta {font-size: 23px;color:#ffffff; font-family: Outfit;font-weight: 700; }
.baslik-4 {color:#ffffff; font-family: Outfit; font-weight: 700; }
.slider .main-slider .swiper-slide .container h1 { font-family: Outfit;color: #ffffff; }
.slider .main-slider .swiper-slide .container p { font-family: Outfit; color: #ffffff;}
.slider .main-slider .swiper-slide .container a { 
    font-family: Outfit;border-radius: 5px; 
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    transition: all 0.9s;
    border:none;
}
.slider .main-slider .swiper-slide .container a:hover{ font-family: Outfit;border-radius: 5px; 
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
    transition: all 0.9s;
    border:none;
}
.custom-button { font-family: Outfit;border:none;color:#ffffff; 
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
}
.custom-buttonw { font-family: Outfit; }
.baslik-sol { font-family: Outfit; }
.member-box figcaption h6 { font-family: Outfit; }
.member-box figcaption p { font-family: Outfit; }
.h2-baslik-hizmetler-2 { font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-hizmetler-21 { font-family: Outfit; font-size: 32px; font-weight: 700; }
.h2-baslik-hizmetler-2111 { color: #d02ef0; font-family: Outfit;font-size: 32px;font-weight: 700; }
.baslik-3-service { font-family: Outfit; }
.paketler3__pr-yazi { font-family: Outfit; }
.paketler3__pr-degeri { font-family: Outfit; font-size: 32px; font-weight: 700; }
.baslik-3 { font-size: 23px;color:#ffffff; font-family: Outfit; }
.footer .widget-title {
    background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent; 
    font-family: Outfit;
    font-weight: 700; 
}
.page-header .container h2 {color:#fff; font-family: Outfit; }
.page-header .container p {color:#fff; font-family: Outfit; }
.page-header .container a {color:#fff; font-family: Outfit; }
.page-header .container a:hover {color:#fff; font-family: Outfit; }
.navbar .site-menu ul li a {font-family: Outfit;color:#fff;}
.navbar .site-menu ul li a:hover {
    background: linear-gradient(to right, #d02ef0 0%, #09cfff 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
}
.navbar-light .navbar-nav .nav-link {color: #fff;}
.wpcf7 form.sent .wpcf7-response-output {
    border-color: #46b450;
    color: white;
}

/* text secondary */
ul.post-categories a:hover {color: #ffffff; font-family: Outfit; font-size: 16px; }
.reply a:hover {color: #ffffff; }
cite.fn a:hover {color: #ffffff; }
time:hover {color: #ffffff; }


/*
responsive
*/

@media only screen and (min-width: 1199px), only screen and (max-width: 1199px) {

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}

@media only screen and (min-width: 991px), only screen and (max-width: 1180px) {

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}

@media only screen and (min-width: 767px), only screen and (max-width: 767px) {

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}

@media (min-width: 820px) and (max-width: 820px) {

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}

@media (min-width: 767px) and (max-width: 850px) { 

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}


@media (min-width: 1180px) and (max-width: 1200px) { 

  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}
  span.menu-service { color: #d02ef0; }
  .iconk {color: #d02ef0;}
  .iconk:hover { color: #09cfff; }
  .icon {background: #d02ef0;}

}

@media (min-width: 1180px) and (max-width: 1180px) { 

.info-or {padding: 15rem 0 30rem;background: #fbfbfb;}

}
.icon {background:none;}
.testimonial-card.testimonial-card {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
}
.testimonial-card.testimonial-card:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
}
.testimon-text {color:#ffffff;}
.quote {
    opacity: 0.4;
    transform: rotate(10deg) translate(-10px, -40px);
    color: #ffffff;
}
.testimonialimg {
    height: 116px;
}
.iconleft {
    font-size:70px;
}
.form-popup__input {
    border-radius: 5px;
    border: 1px solid #ffffff;
    color: #ffffff;
    background: none;
    font-size:18px;
}
input[type="text"] {
    font-size:18px;
}
.iconsv {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
}
.iconsociaf {
    color:#fff;
}
.iconsociaf:hover {
color:#fff;
}
.footer .footer-social li a {
    background-image: linear-gradient(to right, #d02ef0, #09cfff);
    border:none;
}
.footer .footer-social li a:hover {
    background-image: linear-gradient(to right, #09cfff, #d02ef0);
    border:none;
}
p{color:#ffffff;}
@media (min-width: 200px) and (max-width: 1180px) {
    .clouds{
	background-repeat: repeat;
}
}
</style>

<title>Home - EV</title>
<link rel="shortcut icon" type="image/png" href="img//metan-favicion.png">
<meta name="description" content="Custom IT Solutions for Your Business. We are at your service with our reliable service understanding and professional team.">
</head>
<body>
<div class="preloader">
<figure> <img src="img/metan-loader.png" alt="Image"> </figure>
</div>
<div class="page-transition"></div>
<aside class="side-widget">
<div class="inner">
<!-- Logo Menu Mobile -->
    <div class="logo"> <a href="./"><img src="img/metan-logo.png" alt="Image"></a> </div>
    <div class="hide-mobile">
    <div class="or">
        <h2 class="h2-baslik-hizmetler-2"> Contact Information </h2>
    </div>
    <div class="bosluksv"></div>
    <div class="iconsv"><i class="flaticon-call"></i></div>
    <address class="address">

        
        +1 (234) 567 89 10
        
        <div class="bosluksv"></div>


        <div class="iconsv"><i class="flaticon-email"></i></div>

        
        example@example.com
        
        <div class="bosluksv"></div>
        <div class="iconsv"><i class="flaticon-location"></i></div>

        
        New Jersey, USA
        
        <div class="bosluksv"></div>
        <div class="or">

                    <a href="#"><i class="flaticon-facebook-1 iconsocia"></i></a>
         

                    <a href="#"><i class="flaticon-instagram-1 iconsociai"></i></a>
         

                    <a href="#"><i class="flaticon-twitter-1 iconsocia"></i></a>
           

        </div>
    </address>
    </div>
    <div class="show-mobile">
    <div class="site-menu">
        <div class="menu">

        <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse">
            <ul id="menu-mobile-menu" class="nav navbar-nav" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
    <li   class="nav-item"><a itemprop="url" href="./" class="nav-link" aria-current="page"><span itemprop="name">Home</span></a></li>
<li  class=" dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link"><span itemprop="name">About</span></a>
<ul class="dropdown-menu" >
	<li   class=" nav-item"><a itemprop="url" href="./about" class="dropdown-item"><span itemprop="name">About Us</span></a></li>
	<li   class="  nav-item"><a itemprop="url" href="./our-team" class="dropdown-item"><span itemprop="name">Our Team</span></a></li>
	<li   class="  nav-item"><a itemprop="url" href="./privacy-policy" class="dropdown-item"><span itemprop="name">Privacy Policy</span></a></li>
	<li class="  nav-item"><a itemprop="url" href="./term-and-condition" class="dropdown-item"><span itemprop="name">Terms and Conditions</span></a></li>
</ul>
</li>
<li   class="dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link"><span itemprop="name">Features</span></a>
<ul class="dropdown-menu" >
	<li   class="  nav-item"><a itemprop="url" href="./feature" class="dropdown-item"><span itemprop="name">Features</span></a></li>
	<li   class="  nav-item"><a itemprop="url" href="./feature-detail" class="dropdown-item"><span itemprop="name">Feature Detail</span></a></li>
</ul>
</li>
<li   class=" dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link" ><span itemprop="name">Projects</span></a>
<ul class="dropdown-menu" >
	<li   class="  nav-item"><a itemprop="url" href="./project" class="dropdown-item"><span itemprop="name">Projects</span></a></li>
	<li   class="  nav-item"><a itemprop="url" href="./project-detail" class="dropdown-item"><span itemprop="name">Project Detail</span></a></li>
</ul>
</li>
<li  class="  nav-item"><a itemprop="url" href="./blog" class="nav-link"><span itemprop="name">Blog</span></a></li>
<li  class="  nav-item"><a itemprop="url" href="./contact" class="nav-link"><span itemprop="name">Contact</span></a></li>
</ul></div>        </div>
        </div>
    </div>
    <small>
            © 2023 Metan - All Rights Reserved.        
    </small> </div>
</aside>
<nav class="navbar navbar-expand-md navbar-light bg-light">
<div class="container">
<!-- Logo Menu Desktop -->
    <div class="logo"> <a href="./">
                 <img src="img/metan-logo.png" alt="Image">
        
    </a> 
    </div>

        <div class="site-menu">
        <div class="menueffect">
        <div id="bs-example-navbar-collapse-2" class="collapse navbar-collapse">
            <ul class="nav navbar-nav" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
                <li  class="nav-item"><a itemprop="url" href="./" class="nav-link" aria-current="page"><span itemprop="name">Home</span></a></li>
<li   class="dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link" ><span itemprop="name">About</span></a>
<ul class="dropdown-menu" aria-labelledby="">
	<li   class="nav-item"><a itemprop="url" href="./about" class="dropdown-item"><span itemprop="name">About Us</span></a></li>
	<li   class="nav-item"><a itemprop="url" href="./our-team" class="dropdown-item"><span itemprop="name">Our Team</span></a></li>
	<li   class="nav-item"><a itemprop="url" href="./privacy-policy" class="dropdown-item"><span itemprop="name">Privacy Policy</span></a></li>
	<li   class="nav-item"><a itemprop="url" href="./term-and-condition" class="dropdown-item"><span itemprop="name">Terms and Conditions</span></a></li>
</ul>
</li>
<li   class="dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link" ><span itemprop="name">Features</span></a>
<ul class="dropdown-menu" aria-labelledby="">
	<li   class="nav-item"><a itemprop="url" href="./feature" class="dropdown-item"><span itemprop="name">Features</span></a></li>
	<li   class="nav-item"><a itemprop="url" href="./feature-detail" class="dropdown-item"><span itemprop="name">Feature Detail</span></a></li>
</ul>
</li>
<li   class=" dropdown  nav-item"><a href="#" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle nav-link"><span itemprop="name">Projects</span></a>
<ul class="dropdown-menu" aria-labelledby="">
	<li   class="nav-item"><a itemprop="url" href="./project" class="dropdown-item"><span itemprop="name">Projects</span></a></li>
	<li   class="nav-item"><a itemprop="url" href="./project-detail" class="dropdown-item"><span itemprop="name">Project Detail</span></a></li>
</ul>
</li>
<li  class="nav-item"><a itemprop="url" href="./blog" class="nav-link"><span itemprop="name">Blog</span></a></li>
<li   class="nav-item"><a itemprop="url" href="./contact" class="nav-link"><span itemprop="name">Contact</span></a></li>
</ul></div>        </div>
        </div>
        <div class="hamburger-menu"> <span></span> <span></span> <span></span> </div>

        <div class="navbar-button"> <div class="telh" onclick="location.href='#';" style="cursor:pointer;"><i class="flaticon-vr-goggles iconp"></i>&nbsp;&nbsp;&nbsp;Get Your Virtual Land →</div> </div>
    </div>
</nav>