<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>Our Team</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>Our Team</p>
        </div>
        <!-- end container --> 
</header>   
<!--Team Alanı-->
    <section class="team-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wow fadeInUp" data-wow-delay="0.3s">
                    <div class="boslukalt"></div>
                    <h2 class="h2-baslik-hizmetler-2 wow fadeInUp" data-wow-delay="0.4s">Our Professional Team</h2>
                    <p class="h2-baslik-hizmetler-2__paragraf wow fadeInUp" data-wow-delay="0.4s">
                    We are at your service with our competent staff.                    </p>   
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
                                            <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInLeft" data-wow-delay="0.5s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-1.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Robert North</h6>
                                    <p class="paragraf-sol-beyaz-orta">Ceo</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInLeft" data-wow-delay="0.6s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-2.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Adam Doe</h6>
                                    <p class="paragraf-sol-beyaz-orta">Founder</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInRight" data-wow-delay="0.7s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-4.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Elina John</h6>
                                    <p class="paragraf-sol-beyaz-orta">General Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInRight" data-wow-delay="0.8s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-8.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Adam Brown</h6>
                                    <p class="paragraf-sol-beyaz-orta">Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInLeft" data-wow-delay="0.9s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-3.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Elizabeth Doe</h6>
                                    <p class="paragraf-sol-beyaz-orta">Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInLeft" data-wow-delay="1s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-5.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Ryan Jack</h6>
                                    <p class="paragraf-sol-beyaz-orta">Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInRight" data-wow-delay="1.1s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-6.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Robert John</h6>
                                    <p class="paragraf-sol-beyaz-orta">Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
                        <div class="col-xl-3">
                    <div class="class-box">
                        <div class="services-kutu2 wow fadeInRight" data-wow-delay="1.2s" style="cursor:pointer;">
                            <div class="member-box wow reveal-effect">
                                <figure> <img src="img/team-metan-7.jpg" alt="Image">
                                    <figcaption>
                                    <h6>Carl North</h6>
                                    <p class="paragraf-sol-beyaz-orta">Manager</p>
                                    <ul>
                                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                    </ul>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>   
           
          
    </div>
</div>
</section>

<?php include 'footer.php';?> 


