<?php include 'header.php';?> 

<header class="page-header" data-background="">
        <div class="container">
          <h2>Terms and Conditions</h2>
          <p><a href="./" class="headerbreadcrumb">Home</a> <i class="flaticon-right-chevron"></i>Terms and Conditions</p>
        </div>
        <!-- end container --> 
</header>
<section class="hakkimizda-bolumu-anasayfa">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h2><strong>When you use our services, you trust us with your information. We know that this is a huge responsibility, so we go to great lengths to protect your information and ensure you are in control of it.</strong></h2>
<p>&nbsp;</p>
<p>With this Privacy Policy, we aim to help you understand what data we collect and why, and how you can update, manage, transfer, and delete your information.</p>
<p>&nbsp;</p>
<h3><strong>Your Collected Personal Data, Collection Method and Legal Reason</strong></h3>
<p>&nbsp;</p>
<p>Your IP address and user agent information are only used for analytics and cookies etc. will be processed by means of technologies, automatic or non-automatic methods and sometimes obtained from third parties such as analytical providers, advertising networks, search information providers, technology providers, recorded, stored and updated, within the framework and duration of the service and contractual relationship between us, on the basis of the legitimate interest processing condition.</p>
<p>&nbsp;</p>
<h3><strong>Purpose of Processing Your Personal Data</strong></h3>
<p>&nbsp;</p>
<p>Your personal data that you share with us only by analyzing; to fulfill the requirements of the services we offer in the best way, to ensure that these services can be accessed and utilized by you at the maximum level, to develop our services in line with your needs and to bring you together with broader service providers within legal frameworks, will be processed and updated in accordance with its purpose and proportionately during the contract and service period, in order to fulfill the</p>
<p>&nbsp;</p>
<h3><strong>To Whom and For What Purposes the Personal Data Collected Can Be Transferred</strong></h3>
<p>&nbsp;</p>
<p>Your personal data you share with us; It can be transferred to third parties, institutions and organizations at home and abroad, with which we receive and/or provide services to carry out our activities, with whom we have contractual relations, with whom we cooperate, and to judicial and administrative authorities upon request, provided that necessary technical and administrative measures are taken.</p>
        </div>
    </div>
</div>
</section> 
  


<?php include 'footer.php';?> 


